# letterboxd-scraper

Get data from letterboxd in a flash.

## Installation

```bash
pip install letterboxd-scraper
```

## Usage

```python
director = get_director("letterboxd.com/movie/parasite-2019/")
print(director)
``````