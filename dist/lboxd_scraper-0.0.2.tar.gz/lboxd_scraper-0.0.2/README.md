# letterboxd-scraper

Get data from letterboxd in a flash. Example python repo project.

## Installation

```bash
pip install lboxd-scraper
```

## Usage

```python
import lboxd_scraper 
film = lboxd_scraper.Film("letterboxd.com/movie/parasite-2019/")
print(film.director)
``````
