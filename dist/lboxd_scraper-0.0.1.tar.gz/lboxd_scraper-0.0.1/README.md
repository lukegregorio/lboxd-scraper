# letterboxd-scraper

Get data from letterboxd in a flash. Example python repo project.

## Installation

```bash
pip install letterboxd-scraper
```

## Usage

```python
import letterboxd_scraper 
film = Film("letterboxd.com/movie/parasite-2019/")
print(film.director)
``````
